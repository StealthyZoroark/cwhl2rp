local PLUGIN = PLUGIN;

function PLUGIN:GetPlayerInfoText(playerInfoText)
	local rads = Clockwork.Client:GetSharedVar("radiation");
	if (rads) then
		playerInfoText:Add("RAD", "Radiation Level: "..rads);
	end;
end;