--[[
	Name: cl_auto.lua.
	Author: LauScript.
--]]

local PLUGIN = PLUGIN;

-- Called when screen space effects should be rendered.
function PLUGIN:RenderScreenspaceEffects()
end;
